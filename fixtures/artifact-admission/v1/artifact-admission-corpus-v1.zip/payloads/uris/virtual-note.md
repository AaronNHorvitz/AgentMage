# Synthetic virtual document

No ambient workspace authority.
