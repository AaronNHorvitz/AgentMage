# Calculator Fixture

Identity `ee59ec66f0c1`.
