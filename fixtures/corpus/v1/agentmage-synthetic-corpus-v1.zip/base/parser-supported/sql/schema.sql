/* fixture 3db837439fe3 */
CREATE TABLE fixture_record (id INTEGER PRIMARY KEY);
