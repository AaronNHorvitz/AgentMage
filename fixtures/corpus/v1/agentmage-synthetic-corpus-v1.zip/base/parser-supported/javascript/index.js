/* fixture 3db837439fe3 */
export function fixture() { return 'javascript'; }
