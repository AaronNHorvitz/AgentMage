/* fixture 3db837439fe3 */
package main

import "fmt"

func main() { fmt.Println("fixture") }
