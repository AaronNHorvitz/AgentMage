/* fixture 3db837439fe3 */
fn main() { println!("fixture"); }
