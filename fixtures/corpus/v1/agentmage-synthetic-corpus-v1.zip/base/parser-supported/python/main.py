def fixture() -> str:
    return 'python'
