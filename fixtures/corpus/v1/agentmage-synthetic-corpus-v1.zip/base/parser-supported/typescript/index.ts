/* fixture 3db837439fe3 */
export const fixture = (): string => 'typescript';
