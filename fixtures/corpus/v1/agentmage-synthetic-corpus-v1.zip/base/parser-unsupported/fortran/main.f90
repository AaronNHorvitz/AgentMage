program fixture
  print *, 'fixture'
end program fixture
